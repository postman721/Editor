// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#include "appinfo.h"
#include "mainwindow.h"
#include "themes.h"

#include <QApplication>
#include <QCommandLineOption>
#include <QCommandLineParser>
#include <QCoreApplication>
#include <QIcon>
#include <QTextStream>

int main(int argc, char *argv[])
{
    // Set application identity before QCommandLineParser or QSettings is used.
    QApplication application(argc, argv);
    QApplication::setStyle(QStringLiteral("Fusion"));
    QCoreApplication::setOrganizationName(QString::fromLatin1(AppInfo::OrganizationName));
    QCoreApplication::setOrganizationDomain(QString::fromLatin1(AppInfo::OrganizationDomain));
    QCoreApplication::setApplicationName(QString::fromLatin1(AppInfo::CommandName));
    QCoreApplication::setApplicationVersion(QString::fromLatin1(AppInfo::Version));
    QApplication::setApplicationDisplayName(QString::fromLatin1(AppInfo::DisplayName));
    QApplication::setDesktopFileName(QString::fromLatin1(AppInfo::DesktopFileName));
    QApplication::setWindowIcon(QIcon(QStringLiteral(":/icons/plusplus-editor.svg")));

    QCommandLineParser parser;
    parser.setApplicationDescription(
        QApplication::translate(
            "main", "A polished traditional Qt 6 text editor with line numbers."));
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption themeOption(
        {QStringLiteral("t"), QStringLiteral("theme")},
        QApplication::translate("main", "Select lwm-graphite, lwm-dark, or lwm-blue."),
        QApplication::translate("main", "theme"));
    parser.addOption(themeOption);
    parser.addPositionalArgument(
        QApplication::translate("main", "files"),
        QApplication::translate("main", "UTF-8 text files to open."),
        QStringLiteral("[files...]"));
    parser.process(application);

    const QString requestedTheme = parser.value(themeOption);
    Theme parsedTheme = Theme::Graphite;
    if (!requestedTheme.isEmpty() && !Themes::fromKey(requestedTheme, &parsedTheme)) {
        QTextStream error(stderr);
        error << QApplication::translate(
                     "main", "Unknown theme. Choose lwm-graphite, lwm-dark, or lwm-blue.")
              << Qt::endl;
        return 2;
    }

    MainWindow window(requestedTheme);
    window.show();

    // Positional arguments implement: editor++ filename [more-files...]
    // The first file reuses the initial blank tab.
    window.openFiles(parser.positionalArguments());
    return application.exec();
}
