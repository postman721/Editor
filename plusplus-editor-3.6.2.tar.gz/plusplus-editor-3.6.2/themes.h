// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#pragma once

#include <QList>
#include <QString>

class QApplication;

enum class Theme
{
    Graphite,
    Dark,
    Blue
};

// Themes has no state. It maps three names to embedded QSS files and replaces
// the application's one active palette and style sheet.
namespace Themes
{
QList<Theme> all();
QString key(Theme theme);
bool fromKey(const QString &key, Theme *theme);
bool apply(QApplication &application, Theme theme, QString *error = nullptr);
}
