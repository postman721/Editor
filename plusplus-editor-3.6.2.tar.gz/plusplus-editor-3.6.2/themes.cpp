// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#include "themes.h"

#include <QApplication>
#include <QColor>
#include <QFile>
#include <QPalette>
#include <QStringConverter>
#include <QStringDecoder>

namespace
{
QString resourceFor(Theme theme)
{
    switch (theme) {
    case Theme::Graphite:
        return QStringLiteral(":/themes/lwm_graphite.qss");
    case Theme::Dark:
        return QStringLiteral(":/themes/lwm_dark.qss");
    case Theme::Blue:
        return QStringLiteral(":/themes/lwm_blue.qss");
    }
    return QString();
}

QPalette paletteFor(Theme theme)
{
    QColor window;
    QColor windowText;
    QColor base;
    QColor alternateBase;
    QColor text;
    QColor button;
    QColor buttonText;
    QColor highlight;
    QColor highlightedText;
    QColor mid;
    QColor dark;
    QColor light;
    QColor placeholder;
    QColor toolTipBase;
    QColor toolTipText;

    switch (theme) {
    case Theme::Graphite:
        window = QColor(QStringLiteral("#2b3137"));
        windowText = QColor(QStringLiteral("#f1f4f6"));
        base = QColor(QStringLiteral("#fbfaf6"));
        alternateBase = QColor(QStringLiteral("#edf4f7"));
        text = QColor(QStringLiteral("#20262b"));
        button = QColor(QStringLiteral("#414a54"));
        buttonText = QColor(QStringLiteral("#f5f7f8"));
        highlight = QColor(QStringLiteral("#3e9ed5"));
        highlightedText = QColor(QStringLiteral("#ffffff"));
        mid = QColor(QStringLiteral("#74808a"));
        dark = QColor(QStringLiteral("#171b1f"));
        light = QColor(QStringLiteral("#ffffff"));
        placeholder = QColor(QStringLiteral("#87929a"));
        toolTipBase = QColor(QStringLiteral("#fffdf7"));
        toolTipText = text;
        break;
    case Theme::Dark:
        window = QColor(QStringLiteral("#15191e"));
        windowText = QColor(QStringLiteral("#edf3f8"));
        base = QColor(QStringLiteral("#0d1218"));
        alternateBase = QColor(QStringLiteral("#13212b"));
        text = QColor(QStringLiteral("#e7edf3"));
        button = QColor(QStringLiteral("#202832"));
        buttonText = windowText;
        highlight = QColor(QStringLiteral("#2fa8ef"));
        highlightedText = QColor(QStringLiteral("#ffffff"));
        mid = QColor(QStringLiteral("#43515e"));
        dark = QColor(QStringLiteral("#070a0d"));
        light = QColor(QStringLiteral("#33404d"));
        placeholder = QColor(QStringLiteral("#71808d"));
        toolTipBase = QColor(QStringLiteral("#222b35"));
        toolTipText = windowText;
        break;
    case Theme::Blue:
        window = QColor(QStringLiteral("#082743"));
        windowText = QColor(QStringLiteral("#ffffff"));
        base = QColor(QStringLiteral("#0a3155"));
        alternateBase = QColor(QStringLiteral("#0d416e"));
        text = QColor(QStringLiteral("#ffffff"));
        button = QColor(QStringLiteral("#104a7d"));
        buttonText = QColor(QStringLiteral("#ffffff"));
        highlight = QColor(QStringLiteral("#48baf8"));
        highlightedText = QColor(QStringLiteral("#ffffff"));
        mid = QColor(QStringLiteral("#3778a8"));
        dark = QColor(QStringLiteral("#031525"));
        light = QColor(QStringLiteral("#69c5ff"));
        placeholder = QColor(QStringLiteral("#91b9d5"));
        toolTipBase = QColor(QStringLiteral("#123f69"));
        toolTipText = QColor(QStringLiteral("#ffffff"));
        break;
    }

    QPalette palette;
    palette.setColor(QPalette::Window, window);
    palette.setColor(QPalette::WindowText, windowText);
    palette.setColor(QPalette::Base, base);
    palette.setColor(QPalette::AlternateBase, alternateBase);
    palette.setColor(QPalette::Text, text);
    palette.setColor(QPalette::Button, button);
    palette.setColor(QPalette::ButtonText, buttonText);
    palette.setColor(QPalette::BrightText, highlightedText);
    palette.setColor(QPalette::Highlight, highlight);
    palette.setColor(QPalette::HighlightedText, highlightedText);
    palette.setColor(QPalette::Link, highlight);
    palette.setColor(QPalette::Mid, mid);
    palette.setColor(QPalette::Dark, dark);
    palette.setColor(QPalette::Light, light);
    palette.setColor(QPalette::PlaceholderText, placeholder);
    palette.setColor(QPalette::ToolTipBase, toolTipBase);
    palette.setColor(QPalette::ToolTipText, toolTipText);

    const QColor disabledText = QColor::fromRgbF(
        text.redF(), text.greenF(), text.blueF(), 0.45);
    const QColor disabledWindowText = QColor::fromRgbF(
        windowText.redF(), windowText.greenF(), windowText.blueF(), 0.45);
    palette.setColor(QPalette::Disabled, QPalette::Text, disabledText);
    palette.setColor(QPalette::Disabled, QPalette::WindowText, disabledWindowText);
    palette.setColor(QPalette::Disabled, QPalette::ButtonText, disabledWindowText);
    return palette;
}
}

QList<Theme> Themes::all()
{
    return {Theme::Graphite, Theme::Dark, Theme::Blue};
}

QString Themes::key(Theme theme)
{
    switch (theme) {
    case Theme::Graphite:
        return QStringLiteral("lwm-graphite");
    case Theme::Dark:
        return QStringLiteral("lwm-dark");
    case Theme::Blue:
        return QStringLiteral("lwm-blue");
    }
    return QStringLiteral("lwm-graphite");
}

// Theme keys are stable because they are stored in QSettings and used by --theme.
bool Themes::fromKey(const QString &value, Theme *theme)
{
    if (!theme)
        return false;

    const QString normalized = value.trimmed().toLower();
    constexpr Theme candidates[] = {Theme::Graphite, Theme::Dark, Theme::Blue};
    for (Theme candidate : candidates) {
        if (normalized == key(candidate)) {
            *theme = candidate;
            return true;
        }
    }
    return false;
}

// Qt owns one active palette and style sheet, so switching does not accumulate objects.
bool Themes::apply(QApplication &application, Theme theme, QString *error)
{
    QFile file(resourceFor(theme));
    constexpr qint64 maximumThemeBytes = 256 * 1024;

    if (!file.open(QIODevice::ReadOnly)) {
        if (error)
            *error = QApplication::translate("Themes", "Cannot open the embedded theme.");
        return false;
    }
    if (file.size() < 0 || file.size() > maximumThemeBytes) {
        if (error)
            *error = QApplication::translate("Themes", "The embedded theme is invalid.");
        return false;
    }

    const QByteArray bytes = file.read(maximumThemeBytes + 1);
    if (bytes.size() != file.size() || bytes.size() > maximumThemeBytes) {
        if (error)
            *error = QApplication::translate("Themes", "Cannot read the complete theme.");
        return false;
    }

    QStringDecoder decoder(QStringDecoder::Utf8, QStringConverter::Flag::Stateless);
    const QString styleSheet = decoder(bytes);
    if (decoder.hasError()) {
        if (error)
            *error = QApplication::translate("Themes", "The embedded theme is not valid UTF-8.");
        return false;
    }

    const QPalette palette = paletteFor(theme);
    if (application.palette() != palette)
        application.setPalette(palette);

    // Theme selectors use Qt class and objectName properties rather than type
    // and ID selectors. This preserves the appearance while avoiding the Qt
    // 6.8 QCss name/ID hash-index path reported by Memcheck. Avoid reparsing an
    // unchanged sheet when a second window restores the already-active theme.
    if (application.styleSheet() != styleSheet)
        application.setStyleSheet(styleSheet);
    return true;
}
