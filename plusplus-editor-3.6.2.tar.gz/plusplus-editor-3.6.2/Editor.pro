# ++Editor qmake project
# Open this file directly in Qt Creator.

QT += core gui widgets printsupport
CONFIG += c++17 warn_on
TEMPLATE = app
TARGET = editor++
VERSION = 3.6.2

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    form.cpp \
    themes.cpp

HEADERS += \
    appinfo.h \
    mainwindow.h \
    form.h \
    themes.h

FORMS += \
    mainwindow.ui \
    form.ui

RESOURCES += resources.qrc

DEFINES += QT_DEPRECATED_WARNINGS

unix:!macx {
    QMAKE_CXXFLAGS += -Wall -Wextra -Wpedantic
}

# Used by `make sanitize`; normal Qt Creator builds are unaffected.
sanitize {
    QMAKE_CXXFLAGS += -fsanitize=address,undefined -fno-omit-frame-pointer
    QMAKE_LFLAGS += -fsanitize=address,undefined
}

isEmpty(PREFIX): PREFIX = /usr

target.path = $$PREFIX/bin
desktop.files = data/net.techtimejourney.PlusPlusEditor.desktop
desktop.path = $$PREFIX/share/applications
appstream.files = data/net.techtimejourney.PlusPlusEditor.metainfo.xml
appstream.path = $$PREFIX/share/metainfo
icon.files = data/plusplus-editor.svg
icon.path = $$PREFIX/share/icons/hicolor/scalable/apps
manpage.files = data/editor++.1
manpage.path = $$PREFIX/share/man/man1
docs.files = README.md LICENSE
screenshots.files = screenshots/lwm-graphite.png \
    screenshots/lwm-dark.png \
    screenshots/lwm-blue.png
docs.path = $$PREFIX/share/doc/plusplus-editor
license_texts.files = LICENSES/GPL-2.0.txt LICENSES/Apache-2.0.txt
license_texts.path = $$PREFIX/share/doc/plusplus-editor/LICENSES
screenshots.path = $$PREFIX/share/doc/plusplus-editor/screenshots

DISTFILES += \
    README.md \
    screenshots/lwm-graphite.png \
    screenshots/lwm-dark.png \
    screenshots/lwm-blue.png

INSTALLS += target desktop appstream icon manpage docs license_texts screenshots
