// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#pragma once

#include <QtGlobal>

namespace AppInfo
{
inline constexpr char DisplayName[] = "++Editor";
inline constexpr char CommandName[] = "editor++";
// Keep the old settings name so upgrades retain the selected theme.
inline constexpr char SettingsName[] = "plusplus-editor";
inline constexpr char Version[] = "3.6.2";
inline constexpr char OrganizationName[] = "techtimejourney";
inline constexpr char OrganizationDomain[] = "techtimejourney.net";
inline constexpr char DesktopFileName[] = "net.techtimejourney.PlusPlusEditor";

// The editor is intentionally bounded. A small fixed limit is easier to
// reason about than a second memory-management framework on top of Qt.
inline constexpr qint64 MaxFileBytes = 8LL * 1024LL * 1024LL;
inline constexpr int MaxDocumentCharacters = 8 * 1024 * 1024;
inline constexpr int MaxPasteCharacters = 1024 * 1024;
inline constexpr int MaxTabs = 12;
inline constexpr int IoChunkCharacters = 64 * 1024;
}
