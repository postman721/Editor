// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#include "form.h"
#include "ui_form.h"

#include "appinfo.h"

#include <QApplication>
#include <QDialog>
#include <QDir>
#include <QEvent>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFontDatabase>
#include <QInputMethodEvent>
#include <QKeyEvent>
#include <QMessageBox>
#include <QMimeData>
#include <QPaintEvent>
#include <QPalette>
#include <QPainter>
#include <QPrintDialog>
#include <QPrinter>
#include <QResizeEvent>
#include <QSaveFile>
#include <QStringConverter>
#include <QStringDecoder>
#include <QTextBlock>
#include <QTextCursor>
#include <QTextDocument>
#include <QTextEdit>
#include <QTextFormat>

// Line-number gutter

class LineNumberArea final : public QWidget
{
public:
    explicit LineNumberArea(EditorTextEdit *editor)
        : QWidget(editor)
        , editor_(editor)
    {
        setObjectName(QStringLiteral("lineNumberArea"));
        setAttribute(Qt::WA_OpaquePaintEvent);
    }

    QSize sizeHint() const override
    {
        return QSize(editor_->lineNumberAreaWidth(), 0);
    }

protected:
    void paintEvent(QPaintEvent *event) override
    {
        editor_->paintLineNumbers(event);
    }

private:
    EditorTextEdit *editor_;
};

// Bounded editor input

EditorTextEdit::EditorTextEdit(QWidget *parent)
    : QPlainTextEdit(parent)
    , lineNumberArea_(new LineNumberArea(this))
{
    setCursorWidth(2);
    setPlaceholderText(tr("Start writing, or drop a UTF-8 text file here…"));
    setTabStopDistance(fontMetrics().horizontalAdvance(QLatin1Char(' ')) * 4.0);
    document()->setDocumentMargin(10.0);

    connect(this, &QPlainTextEdit::blockCountChanged,
            this, [this] { updateLineNumberAreaWidth(); });
    connect(this, &QPlainTextEdit::updateRequest,
            this, &EditorTextEdit::updateLineNumberArea);
    connect(this, &QPlainTextEdit::cursorPositionChanged, this, [this] {
        lineNumberArea_->update();
        highlightCurrentLine();
    });

    updateLineNumberAreaWidth();
    highlightCurrentLine();
}

// Account for selected text because an insertion replaces that selection.
bool EditorTextEdit::canInsert(qsizetype incomingCharacters) const
{
    const QTextCursor cursor = textCursor();
    const qint64 current = qMax(0, document()->characterCount() - 1);
    const qint64 selected = cursor.selectionEnd() - cursor.selectionStart();
    const qint64 incoming = qMax<qint64>(0, static_cast<qint64>(incomingCharacters));
    const qint64 result = current - qMin(current, selected) + incoming;
    return result <= AppInfo::MaxDocumentCharacters;
}

// Clipboard and text-drop input share one bounded insertion path.
void EditorTextEdit::insertFromMimeData(const QMimeData *source)
{
    if (!source || !source->hasText())
        return;

    const QString text = source->text();
    if (text.size() > AppInfo::MaxPasteCharacters) {
        QApplication::beep();
        emit inputRejected(tr("Paste and text-drop input is limited to 1 Mi characters."));
        return;
    }
    if (!canInsert(text.size())) {
        QApplication::beep();
        emit inputRejected(tr("The document has reached its 8 Mi-character limit."));
        return;
    }
    insertPlainText(text);
}

void EditorTextEdit::inputMethodEvent(QInputMethodEvent *event)
{
    const QString committedText = event->commitString();
    if (!committedText.isEmpty() && !canInsert(committedText.size())) {
        QApplication::beep();
        emit inputRejected(tr("The document has reached its 8 Mi-character limit."));
        event->ignore();
        return;
    }
    QPlainTextEdit::inputMethodEvent(event);
}

void EditorTextEdit::keyPressEvent(QKeyEvent *event)
{
    const QString text = event->text();
    bool insertsText = false;
    for (QChar character : text) {
        if (character.isPrint() || character == QLatin1Char('\n')
            || character == QLatin1Char('\r') || character == QLatin1Char('\t')) {
            insertsText = true;
            break;
        }
    }

    if (insertsText && !canInsert(text.size())) {
        QApplication::beep();
        emit inputRejected(tr("The document has reached its 8 Mi-character limit."));
        event->ignore();
        return;
    }
    QPlainTextEdit::keyPressEvent(event);
}

int EditorTextEdit::lineNumberAreaWidth() const
{
    int digits = 1;
    for (int lines = qMax(1, blockCount()); lines >= 10; lines /= 10)
        ++digits;
    return 16 + fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits;
}

// QPlainTextEdit stores this as one lightweight extra selection.
void EditorTextEdit::highlightCurrentLine()
{
    QTextEdit::ExtraSelection selection;
    selection.cursor = textCursor();
    selection.cursor.clearSelection();
    selection.format.setBackground(palette().color(QPalette::AlternateBase));
    selection.format.setProperty(QTextFormat::FullWidthSelection, true);
    setExtraSelections({selection});
}

void EditorTextEdit::updateLineNumberAreaWidth()
{
    const int width = lineNumberAreaWidth();
    setViewportMargins(width, 0, 0, 0);
    if (lineNumberArea_) {
        const QRect area = contentsRect();
        lineNumberArea_->setGeometry(QRect(area.left(), area.top(), width, area.height()));
    }
}

void EditorTextEdit::updateLineNumberArea(const QRect &rect, int dy)
{
    if (dy != 0)
        lineNumberArea_->scroll(0, dy);
    else
        lineNumberArea_->update(0, rect.y(), lineNumberArea_->width(), rect.height());

    if (rect.contains(viewport()->rect()))
        updateLineNumberAreaWidth();
}

void EditorTextEdit::resizeEvent(QResizeEvent *event)
{
    QPlainTextEdit::resizeEvent(event);
    const QRect area = contentsRect();
    lineNumberArea_->setGeometry(
        QRect(area.left(), area.top(), lineNumberAreaWidth(), area.height()));
}

void EditorTextEdit::changeEvent(QEvent *event)
{
    QPlainTextEdit::changeEvent(event);
    if (event->type() == QEvent::FontChange
        || event->type() == QEvent::PaletteChange
        || event->type() == QEvent::StyleChange) {
        setTabStopDistance(fontMetrics().horizontalAdvance(QLatin1Char(' ')) * 4.0);
        updateLineNumberAreaWidth();
        highlightCurrentLine();
        lineNumberArea_->update();
    }
}

// Paint only visible blocks; the gutter stores no copy of the document.
void EditorTextEdit::paintLineNumbers(QPaintEvent *event)
{
    QPainter painter(lineNumberArea_);
    const QPalette gutterPalette = lineNumberArea_->palette();
    painter.fillRect(event->rect(), gutterPalette.color(QPalette::Window));
    painter.setPen(gutterPalette.color(QPalette::Mid));
    painter.drawLine(lineNumberArea_->width() - 1, event->rect().top(),
                     lineNumberArea_->width() - 1, event->rect().bottom());

    QTextBlock block = firstVisibleBlock();
    int blockNumber = block.blockNumber();
    int top = qRound(blockBoundingGeometry(block).translated(contentOffset()).top());
    int bottom = top + qRound(blockBoundingRect(block).height());
    const int currentBlock = textCursor().blockNumber();

    QFont numberFont = font();
    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            const bool current = blockNumber == currentBlock;
            if (current) {
                QColor highlight = palette().color(QPalette::Highlight);
                QColor wash = highlight;
                wash.setAlpha(34);
                painter.fillRect(0, top, lineNumberArea_->width() - 1, bottom - top, wash);
                painter.fillRect(0, top, 3, bottom - top, highlight);
            }

            numberFont.setBold(current);
            painter.setFont(numberFont);
            painter.setPen(current ? palette().color(QPalette::Highlight)
                                   : gutterPalette.color(QPalette::WindowText));
            painter.drawText(0, top, lineNumberArea_->width() - 8,
                             fontMetrics().height(), Qt::AlignRight,
                             QString::number(blockNumber + 1));
        }

        block = block.next();
        ++blockNumber;
        top = bottom;
        if (block.isValid())
            bottom = top + qRound(blockBoundingRect(block).height());
    }
}

// One document tab

Form::Form(int untitledNumber, QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Form)
    , untitledNumber_(untitledNumber)
{
    ui->setupUi(this);
    ui->textEdit->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    // Widget initialization must never turn a new document into an unsaved edit.
    ui->textEdit->document()->setModified(false);

    connect(ui->textEdit->document(), &QTextDocument::modificationChanged,
            this, &Form::titleChanged);
    connect(ui->textEdit, &QPlainTextEdit::cursorPositionChanged, this, [this] {
        const QTextCursor cursor = ui->textEdit->textCursor();
        emit cursorChanged(cursor.blockNumber() + 1, cursor.positionInBlock() + 1);
    });
    connect(ui->textEdit, &EditorTextEdit::inputRejected,
            this, &Form::message);
}

Form::~Form()
{
    delete ui;
}

EditorTextEdit *Form::editor() const
{
    return ui->textEdit;
}

QString Form::filePath() const
{
    return filePath_;
}

QString Form::displayName() const
{
    return filePath_.isEmpty()
               ? tr("Untitled %1").arg(untitledNumber_)
               : QFileInfo(filePath_).fileName();
}

bool Form::isUntitled() const
{
    return filePath_.isEmpty();
}

bool Form::isModified() const
{
    return ui->textEdit->document()->isModified();
}

bool Form::isBlank() const
{
    return isUntitled() && !isModified()
           && ui->textEdit->document()->characterCount() <= 1;
}

// File operations

// Validate the complete UTF-8 input before replacing the current document.
bool Form::openFile(const QString &path, QString *error)
{
    const QFileInfo info(path);
    if (!info.exists() || !info.isFile()) {
        if (error)
            *error = tr("The file does not exist: %1").arg(QDir::toNativeSeparators(path));
        return false;
    }
    if (info.size() < 0 || info.size() > AppInfo::MaxFileBytes) {
        if (error)
            *error = tr("Files larger than 8 MiB are not opened by this compact editor.");
        return false;
    }

    const QString absolutePath = info.absoluteFilePath();
    QFile file(absolutePath);
    if (!file.open(QIODevice::ReadOnly)) {
        if (error)
            *error = tr("Cannot open %1: %2")
                         .arg(QDir::toNativeSeparators(path), file.errorString());
        return false;
    }

    QByteArray bytes = file.read(AppInfo::MaxFileBytes + 1);
    if (static_cast<qint64>(bytes.size()) > AppInfo::MaxFileBytes) {
        if (error)
            *error = tr("The file grew beyond the 8 MiB limit while it was being read.");
        return false;
    }
    if (!file.atEnd() || file.error() != QFileDevice::NoError) {
        if (error)
            *error = tr("Cannot read the complete file: %1").arg(file.errorString());
        return false;
    }

    // Stateless decoding makes an incomplete UTF-8 sequence at end-of-file an
    // error instead of retaining it as decoder state.
    QStringDecoder decoder(QStringDecoder::Utf8, QStringConverter::Flag::Stateless);
    QString text = decoder(bytes);
    if (decoder.hasError()) {
        if (error)
            *error = tr("The file is not valid UTF-8 text.");
        return false;
    }
    if (text.size() > AppInfo::MaxDocumentCharacters) {
        if (error)
            *error = tr("The decoded document exceeds the 8 Mi-character limit.");
        return false;
    }
    if (text.contains(QChar::Null)) {
        if (error)
            *error = tr("The file contains NUL characters and is not plain text.");
        return false;
    }

    // Release the byte buffer before Qt copies the decoded text into its document.
    bytes.clear();
    bytes.squeeze();
    text.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    text.replace(QLatin1Char('\r'), QLatin1Char('\n'));

    QTextDocument *document = ui->textEdit->document();
    ui->textEdit->setUpdatesEnabled(false);
    document->setUndoRedoEnabled(false);
    ui->textEdit->setPlainText(text);
    document->setUndoRedoEnabled(true);
    document->setModified(false);
    ui->textEdit->setUpdatesEnabled(true);
    ui->textEdit->moveCursor(QTextCursor::Start);

    const QString canonical = info.canonicalFilePath();
    setFilePath(canonical.isEmpty() ? absolutePath : canonical);
    emit message(tr("Opened %1").arg(QDir::toNativeSeparators(filePath_)));
    return true;
}

// Stream chunks through QSaveFile for an atomic, memory-bounded save.
bool Form::saveFile(const QString &path, QString *error)
{
    if (path.trimmed().isEmpty()) {
        if (error)
            *error = tr("No destination file was selected.");
        return false;
    }

    const QString absolutePath = QFileInfo(path).absoluteFilePath();
    QSaveFile file(absolutePath);
    file.setDirectWriteFallback(false);
    if (!file.open(QIODevice::WriteOnly)) {
        if (error)
            *error = tr("Cannot save %1: %2")
                         .arg(QDir::toNativeSeparators(path), file.errorString());
        return false;
    }

    QTextDocument *document = ui->textEdit->document();
    const int end = qMax(0, document->characterCount() - 1);
    QTextCursor cursor(document);
    qint64 writtenBytes = 0;

    for (int position = 0; position < end;) {
        int length = qMin(AppInfo::IoChunkCharacters, end - position);

        // QTextCursor positions use UTF-16 code units. Keep a surrogate pair
        // in one chunk so non-BMP characters are never split during UTF-8
        // encoding.
        if (position + length < end
            && document->characterAt(position + length - 1).isHighSurrogate()
            && document->characterAt(position + length).isLowSurrogate()) {
            ++length;
        }

        cursor.setPosition(position);
        cursor.setPosition(position + length, QTextCursor::KeepAnchor);

        QString chunk = cursor.selectedText();
        chunk.replace(QChar::ParagraphSeparator, QLatin1Char('\n'));
        chunk.replace(QChar::LineSeparator, QLatin1Char('\n'));
        const QByteArray encoded = chunk.toUtf8();
        const qint64 encodedSize = encoded.size();
        writtenBytes += encodedSize;

        if (writtenBytes > AppInfo::MaxFileBytes
            || file.write(encoded) != encodedSize) {
            file.cancelWriting();
            if (error) {
                *error = writtenBytes > AppInfo::MaxFileBytes
                             ? tr("The UTF-8 output exceeds the 8 MiB save limit.")
                             : tr("Cannot write the complete file: %1").arg(file.errorString());
            }
            return false;
        }
        position += length;
    }

    if (!file.commit()) {
        if (error)
            *error = tr("Cannot replace the destination atomically: %1")
                         .arg(file.errorString());
        return false;
    }

    const QFileInfo savedInfo(absolutePath);
    const QString canonical = savedInfo.canonicalFilePath();
    setFilePath(canonical.isEmpty() ? savedInfo.absoluteFilePath() : canonical);
    document->setModified(false);
    emit message(tr("Saved %1").arg(QDir::toNativeSeparators(filePath_)));
    return true;
}

bool Form::save(QWidget *dialogParent)
{
    if (filePath_.isEmpty())
        return saveAs(dialogParent);

    QString error;
    if (saveFile(filePath_, &error))
        return true;
    QMessageBox::warning(dialogParent, tr("Save failed"), error);
    return false;
}

bool Form::saveAs(QWidget *dialogParent)
{
    const QString initialPath = filePath_.isEmpty()
                                    ? QDir::homePath() + QStringLiteral("/untitled.txt")
                                    : filePath_;
    const QString path = QFileDialog::getSaveFileName(
        dialogParent, tr("Save text file"), initialPath,
        tr("Text files (*.txt *.md *.log *.json *.xml);;All files (*)"));
    if (path.isEmpty())
        return false;

    QString error;
    if (saveFile(path, &error))
        return true;
    QMessageBox::warning(dialogParent, tr("Save failed"), error);
    return false;
}

bool Form::confirmClose(QWidget *dialogParent)
{
    if (!isModified())
        return true;

    const QMessageBox::StandardButton answer = QMessageBox::warning(
        dialogParent, tr("Unsaved changes"),
        tr("Save changes to %1?").arg(displayName()),
        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel,
        QMessageBox::Save);

    if (answer == QMessageBox::Cancel)
        return false;
    if (answer == QMessageBox::Save)
        return save(dialogParent);
    return true;
}

void Form::printDocument(QWidget *dialogParent)
{
    QPrinter printer(QPrinter::HighResolution);
    QPrintDialog dialog(&printer, dialogParent);
    if (dialog.exec() == QDialog::Accepted)
        ui->textEdit->print(&printer);
}

void Form::setWordWrap(bool enabled)
{
    ui->textEdit->setLineWrapMode(enabled ? QPlainTextEdit::WidgetWidth
                                          : QPlainTextEdit::NoWrap);
}

void Form::setFilePath(const QString &path)
{
    filePath_ = path;
    ui->textEdit->document()->setMetaInformation(QTextDocument::DocumentTitle,
                                                  displayName());
    emit titleChanged();
}
