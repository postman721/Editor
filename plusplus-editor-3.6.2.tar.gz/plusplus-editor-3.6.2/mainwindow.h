// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#pragma once

#include "themes.h"

#include <QMainWindow>
#include <QStringList>

class QActionGroup;
class QCloseEvent;
class QDragEnterEvent;
class QDropEvent;
class QFont;
class QFontComboBox;
class QLabel;
class QSpinBox;
class QTextCharFormat;
class EditorTextEdit;
class Form;

namespace Ui
{
class MainWindow;
}

// MainWindow keeps the same role as in the original project: it owns the tab
// widget and shared controls. Each tab is a self-contained Form.
class MainWindow final : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(const QString &startupTheme = QString(), QWidget *parent = nullptr);
    ~MainWindow() override;

    int tabCount() const;
    Form *currentForm() const;
    Theme currentTheme() const;
    bool openFile(const QString &path);
    // Returns the number of files opened; main.cpp uses this for arguments.
    int openFiles(const QStringList &paths);

public slots:
    void newTab();
    void closeTab(int index);

protected:
    void closeEvent(QCloseEvent *event) override;
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dropEvent(QDropEvent *event) override;

private:
    // Keep setup in this class, but name each responsibility clearly.
    void setupInterface();
    void setupThemeActions();
    void setupActionIcons();
    void connectActions();

    Form *addForm();
    Form *formAt(int index) const;
    EditorTextEdit *currentEditor() const;
    int indexOfOpenFile(const QString &path) const;

    void openDialog();
    void saveCurrent();
    void saveCurrentAs();
    void printCurrent();
    void findText();

    void setBold(bool enabled);
    void setItalic(bool enabled);
    void setUnderline(bool enabled);
    void chooseTextColor();
    void setEditorFont(const QFont &font);
    void setEditorFontSize(int pointSize);
    void mergeFormat(const QTextCharFormat &format);
    void setWordWrap(bool enabled);

    void updateTabTitle(Form *form);
    void updateActions();
    void updateFormatControls();
    void setTheme(Theme theme, bool saveChoice = true);
    void loadSettings(const QString &startupTheme);
    void fitWindowToScreen(bool useDefaultSize);
    void saveSettings();
    void showAbout();

    Ui::MainWindow *ui;
    QLabel *pathLabel_ = nullptr;
    QLabel *cursorLabel_ = nullptr;
    QFontComboBox *fontComboBox_ = nullptr;
    QSpinBox *fontSizeSpinBox_ = nullptr;
    QActionGroup *themeActions_ = nullptr;
    QString lastSearch_;
    Theme currentTheme_ = Theme::Graphite;
    bool wordWrap_ = true;
    int nextUntitledNumber_ = 1;
};
