// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#include "appinfo.h"
#include "form.h"
#include "mainwindow.h"
#include "themes.h"

#include <QAction>
#include <QApplication>
#include <QByteArray>
#include <QCoreApplication>
#include <QColor>
#include <QEvent>
#include <QFile>
#include <QFontComboBox>
#include <QGuiApplication>
#include <QLabel>
#include <QMenuBar>
#include <QPalette>
#include <QPoint>
#include <QPointer>
#include <QRect>
#include <QScreen>
#include <QSettings>
#include <QSpinBox>
#include <QStatusBar>
#include <QSizePolicy>
#include <QTabBar>
#include <QTabWidget>
#include <QTemporaryDir>
#include <QTextCursor>
#include <QToolBar>
#include <QToolButton>
#include <QTextEdit>
#include <QTextFormat>
#include <QtLogging>
#include <QtTest>

#include <cstdio>

namespace
{
QtMessageHandler previousMessageHandler = nullptr;

// Flush deferred QObject destruction between tests and again before QApplication
// exits. Two passes also handle objects queued by another deferred destructor.
void drainDeferredDeletes()
{
    for (int pass = 0; pass < 2; ++pass) {
        QCoreApplication::sendPostedEvents(nullptr, QEvent::DeferredDelete);
        QCoreApplication::processEvents();
    }
}

// The offscreen QPA plugin cannot propagate native window size hints. That
// limitation is expected in headless QWidget tests and is unrelated to the
// application. Suppress only this exact plugin message; every other Qt
// warning still goes through Qt Test's normal logger.
void testMessageHandler(QtMsgType type, const QMessageLogContext &context,
                        const QString &message)
{
    const QString platform = QGuiApplication::platformName();
    const bool headless = platform == QStringLiteral("offscreen")
                          || platform == QStringLiteral("minimal");
    if (type == QtWarningMsg && headless
        && message == QStringLiteral(
            "This plugin does not support propagateSizeHints()")) {
        return;
    }

    if (previousMessageHandler) {
        previousMessageHandler(type, context, message);
        return;
    }

    const QByteArray formatted =
        qFormatLogMessage(type, context, message).toLocal8Bit();
    std::fprintf(stderr, "%s\n", formatted.constData());
}
}

class EditorTests final : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase()
    {
        initialPalette_ = qApp->palette();
        initialStyleSheet_ = qApp->styleSheet();
        previousMessageHandler = qInstallMessageHandler(testMessageHandler);
        QVERIFY(settingsDirectory_.isValid());
        QCoreApplication::setOrganizationName(
            QString::fromLatin1(AppInfo::OrganizationName));
        QCoreApplication::setApplicationName(
            QString::fromLatin1(AppInfo::CommandName));
        QSettings::setDefaultFormat(QSettings::IniFormat);
        QSettings::setPath(QSettings::IniFormat, QSettings::UserScope,
                           settingsDirectory_.path());
    }

    void init()
    {
        QSettings settings(QString::fromLatin1(AppInfo::OrganizationName),
                           QString::fromLatin1(AppInfo::SettingsName));
        settings.clear();
        settings.sync();
        QCOMPARE(settings.status(), QSettings::NoError);
    }

    void cleanup()
    {
        drainDeferredDeletes();
    }

    void cleanupTestCase()
    {
        QSettings settings(QString::fromLatin1(AppInfo::OrganizationName),
                           QString::fromLatin1(AppInfo::SettingsName));
        settings.clear();
        settings.sync();

        // QApplication owns the active theme data. Restore the state that the
        // test executable inherited so Qt can release theme-specific caches.
        qApp->setStyleSheet(initialStyleSheet_);
        qApp->setPalette(initialPalette_);
        drainDeferredDeletes();

        qInstallMessageHandler(previousMessageHandler);
        previousMessageHandler = nullptr;
    }

    void themeSelectionSurvivesRestart()
    {
        {
            MainWindow firstWindow;
            QAction *darkAction = firstWindow.findChild<QAction *>(
                QStringLiteral("actionDark"));
            QVERIFY(darkAction);
            darkAction->trigger();
            QCOMPARE(Themes::key(firstWindow.currentTheme()),
                     Themes::key(Theme::Dark));
        }

        QSettings settings(QString::fromLatin1(AppInfo::OrganizationName),
                           QString::fromLatin1(AppInfo::SettingsName));
        settings.sync();
        QCOMPARE(settings.status(), QSettings::NoError);
        QCOMPARE(settings.value(QStringLiteral("theme")).toString(),
                 Themes::key(Theme::Dark));

        MainWindow restartedWindow;
        QCOMPARE(Themes::key(restartedWindow.currentTheme()),
                 Themes::key(Theme::Dark));
        QAction *darkAction = restartedWindow.findChild<QAction *>(
            QStringLiteral("actionDark"));
        QVERIFY(darkAction && darkAction->isChecked());
    }

    void startupThemeIsSavedForRestart()
    {
        {
            MainWindow themedWindow(Themes::key(Theme::Blue));
            QCOMPARE(Themes::key(themedWindow.currentTheme()),
                     Themes::key(Theme::Blue));
        }

        MainWindow restartedWindow;
        QCOMPARE(Themes::key(restartedWindow.currentTheme()),
                 Themes::key(Theme::Blue));
    }

    void newWindowStartsWithReusableBlankTab()
    {
        MainWindow window;
        QCOMPARE(window.tabCount(), 1);
        QVERIFY(window.currentForm());
        QVERIFY(!window.currentForm()->isModified());
        QVERIFY(window.currentForm()->isBlank());
    }

    void positionalFilesOpenInInitialTab()
    {
        QTemporaryDir directory;
        QVERIFY(directory.isValid());
        const QString path = directory.filePath(QStringLiteral("argument.txt"));
        const QByteArray contents("opened from a positional argument\n");

        QFile file(path);
        QVERIFY(file.open(QIODevice::WriteOnly));
        QCOMPARE(file.write(contents), qint64(contents.size()));
        file.close();

        MainWindow window;
        Form *initialForm = window.currentForm();
        QVERIFY(initialForm && initialForm->isBlank());

        // main.cpp passes positional arguments through this same method.
        QCOMPARE(window.openFiles(QStringList{path}), 1);
        QCOMPARE(window.tabCount(), 1);
        QCOMPARE(window.currentForm(), initialForm);
        QCOMPARE(window.currentForm()->editor()->toPlainText(),
                 QString::fromUtf8(contents));
    }

    void allThemesLoad()
    {
        QList<QColor> editorBackgrounds;
        for (Theme theme : Themes::all()) {
            QString error;
            QVERIFY2(Themes::apply(*qApp, theme, &error), qPrintable(error));
            QVERIFY(!qApp->styleSheet().isEmpty());
            editorBackgrounds.append(qApp->palette().color(QPalette::Base));
        }
        QCOMPARE(editorBackgrounds.size(), 3);
        QVERIFY(editorBackgrounds.at(0) != editorBackgrounds.at(1));
        QVERIFY(editorBackgrounds.at(1) != editorBackgrounds.at(2));
    }

    void utf8RoundTrip()
    {
        QTemporaryDir directory;
        QVERIFY(directory.isValid());
        const QString path = directory.filePath(QStringLiteral("roundtrip.txt"));
        const QString expected = QString::fromUtf8("First line\nHelsinki: äö\n終わり");

        Form writer(1);
        writer.editor()->setPlainText(expected);
        QString error;
        QVERIFY2(writer.saveFile(path, &error), qPrintable(error));

        Form reader(2);
        QVERIFY2(reader.openFile(path, &error), qPrintable(error));
        QCOMPARE(reader.editor()->toPlainText(), expected);
        QVERIFY(!reader.isModified());
    }

    void nonBmpCharacterAtSaveChunkBoundary()
    {
        QTemporaryDir directory;
        QVERIFY(directory.isValid());
        const QString path = directory.filePath(QStringLiteral("unicode-boundary.txt"));
        const QString expected = QString(AppInfo::IoChunkCharacters - 1, QLatin1Char('a'))
                                 + QString::fromUtf8("😀")
                                 + QStringLiteral(" tail");

        Form writer(1);
        writer.editor()->setPlainText(expected);
        QString error;
        QVERIFY2(writer.saveFile(path, &error), qPrintable(error));

        Form reader(2);
        QVERIFY2(reader.openFile(path, &error), qPrintable(error));
        QCOMPARE(reader.editor()->toPlainText(), expected);
    }

    void oversizedFileIsRejected()
    {
        QTemporaryDir directory;
        QVERIFY(directory.isValid());
        const QString path = directory.filePath(QStringLiteral("large.txt"));
        QFile file(path);
        QVERIFY(file.open(QIODevice::WriteOnly));
        QVERIFY(file.resize(AppInfo::MaxFileBytes + 1));
        file.close();

        Form form(1);
        QString error;
        QVERIFY(!form.openFile(path, &error));
        QVERIFY(!error.isEmpty());
    }

    void incompleteUtf8IsRejected()
    {
        QTemporaryDir directory;
        QVERIFY(directory.isValid());
        const QString path = directory.filePath(QStringLiteral("truncated-utf8.txt"));
        QFile file(path);
        QVERIFY(file.open(QIODevice::WriteOnly));
        QCOMPARE(file.write(QByteArray::fromHex("e282")), qint64(2));
        file.close();

        Form form(1);
        QString error;
        QVERIFY(!form.openFile(path, &error));
        QVERIFY(error.contains(QStringLiteral("UTF-8")));
    }

    void lineNumberGutterTracksDocument()
    {
        Form form(1);
        form.resize(640, 420);
        form.show();
        QTest::qWait(20);

        QWidget *gutter = form.findChild<QWidget *>(QStringLiteral("lineNumberArea"));
        QVERIFY(gutter);
        QVERIFY(gutter->isVisibleTo(&form));
        const int oneDigitWidth = gutter->width();
        QVERIFY(oneDigitWidth > 0);

        QString text;
        for (int line = 1; line <= 120; ++line)
            text += QStringLiteral("line %1\n").arg(line);
        form.editor()->setPlainText(text);

        QTRY_VERIFY(gutter->width() > oneDigitWidth);
        QCOMPARE(form.editor()->blockCount(), 121);
    }

    void currentLineUsesThemeHighlight()
    {
        QString error;
        QVERIFY2(Themes::apply(*qApp, Theme::Dark, &error), qPrintable(error));

        Form form(1);
        form.editor()->setPlainText(QStringLiteral("first\nsecond\nthird"));
        QTextCursor cursor = form.editor()->textCursor();
        cursor.movePosition(QTextCursor::Down);
        form.editor()->setTextCursor(cursor);

        const QList<QTextEdit::ExtraSelection> selections =
            form.editor()->extraSelections();
        QCOMPARE(selections.size(), 1);
        QCOMPARE(selections.constFirst().cursor.blockNumber(), 1);
        QCOMPARE(selections.constFirst().format.background().color(),
                 form.editor()->palette().color(QPalette::AlternateBase));
        QVERIFY(selections.constFirst().format.boolProperty(
            QTextFormat::FullWidthSelection));
    }

    void startupWindowFitsScreenAndToolbar()
    {
        MainWindow window;
        window.show();
        QTest::qWait(20);

        QScreen *screen = window.screen();
        QVERIFY(screen);
        const QRect available = screen->availableGeometry();
        QVERIFY(window.width() <= available.width());
        QVERIFY(window.height() <= available.height());

        QToolBar *toolbar = window.findChild<QToolBar *>(QStringLiteral("mainToolBar"));
        QFontComboBox *fontBox = window.findChild<QFontComboBox *>(
            QStringLiteral("fontComboBox"));
        QSpinBox *fontSize = window.findChild<QSpinBox *>(
            QStringLiteral("fontSizeSpinBox"));
        QVERIFY(toolbar);
        QVERIFY(fontBox);
        QVERIFY(fontSize);
        QVERIFY(!toolbar->isMovable());
        QVERIFY(!toolbar->isFloatable());
        QVERIFY(fontBox->isVisibleTo(&window));
        QVERIFY(fontSize->isVisibleTo(&window));

        for (QAction *action : toolbar->actions()) {
            if (action->isSeparator())
                continue;
            QWidget *widget = toolbar->widgetForAction(action);
            QVERIFY2(widget && widget->isVisibleTo(toolbar),
                     qPrintable(action->objectName()));
            const QRect widgetRect(widget->mapTo(toolbar, QPoint(0, 0)), widget->size());
            QVERIFY2(toolbar->rect().contains(widgetRect),
                     qPrintable(action->objectName()));
        }

        QVERIFY(window.menuBar()->isVisibleTo(&window));
        QVERIFY(window.statusBar()->isVisibleTo(&window));
        QTabWidget *tabs = window.findChild<QTabWidget *>(QStringLiteral("tabWidget"));
        QVERIFY(tabs && tabs->isVisibleTo(&window));

        QLabel *pathLabel = window.findChild<QLabel *>(QStringLiteral("pathLabel"));
        QLabel *encodingLabel = window.findChild<QLabel *>(
            QStringLiteral("encodingLabel"));
        QLabel *cursorLabel = window.findChild<QLabel *>(
            QStringLiteral("cursorLabel"));
        QToolButton *newTabButton = window.findChild<QToolButton *>(
            QStringLiteral("newTabButton"));
        QVERIFY(pathLabel);
        QVERIFY(encodingLabel && encodingLabel->isVisibleTo(&window));
        QVERIFY(cursorLabel && cursorLabel->isVisibleTo(&window));
        QVERIFY(newTabButton && newTabButton->isVisibleTo(&window));
        QCOMPARE(pathLabel->sizePolicy().horizontalPolicy(), QSizePolicy::Ignored);

        const QStringList formatButtons = {
            QStringLiteral("boldButton"),
            QStringLiteral("italicButton"),
            QStringLiteral("underlineButton"),
            QStringLiteral("textColorButton")
        };
        for (const QString &name : formatButtons) {
            QToolButton *button = window.findChild<QToolButton *>(name);
            QVERIFY2(button && button->isVisibleTo(toolbar), qPrintable(name));
            QVERIFY2(!button->text().isEmpty(), qPrintable(name));
        }
    }

    void repeatedTabCloseDestroysForms()
    {
        MainWindow window;

        for (int iteration = 0; iteration < 32; ++iteration) {
            QPointer<Form> closing = window.currentForm();
            QVERIFY(!closing.isNull());
            QVERIFY2(closing->isBlank(),
                     "A fresh tab must stay clean; otherwise closeTab opens a modal prompt.");

            window.closeTab(0);
            QCoreApplication::sendPostedEvents(nullptr, QEvent::DeferredDelete);
            QCoreApplication::processEvents();

            QVERIFY(closing.isNull());
            QCOMPARE(window.tabCount(), 1);
        }
    }

    void doubleClickingExistingTabCreatesOne()
    {
        MainWindow window;
        window.show();
        QTest::qWait(20);

        QTabWidget *tabs = window.findChild<QTabWidget *>(QStringLiteral("tabWidget"));
        QVERIFY(tabs);
        QCOMPARE(tabs->count(), 1);

        QTest::mouseDClick(tabs->tabBar(), Qt::LeftButton, Qt::NoModifier,
                          tabs->tabBar()->tabRect(0).center());
        QTRY_COMPARE(tabs->count(), 2);
    }

private:
    QPalette initialPalette_;
    QString initialStyleSheet_;
    QTemporaryDir settingsDirectory_;
};

int main(int argc, char *argv[])
{
    // Keep the native test executable deterministic even when it is started
    // directly from Qt Creator instead of through the project Makefile. These
    // values must be set before QApplication selects its platform integration.
    if (qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM"))
        qputenv("QT_QPA_PLATFORM", QByteArray("offscreen"));
    qputenv("QT_NO_GLIB", QByteArray("1"));
    if (qEnvironmentVariableIsEmpty("QT_STYLE_OVERRIDE"))
        qputenv("QT_STYLE_OVERRIDE", QByteArray("Fusion"));

    QApplication application(argc, argv);
    int result = 0;
    {
        EditorTests tests;
        result = QTest::qExec(&tests, argc, argv);
    }
    drainDeferredDeletes();
    return result;
}

#include "tst_editor.moc"
