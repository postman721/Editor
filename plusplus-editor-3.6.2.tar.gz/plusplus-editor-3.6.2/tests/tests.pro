QT += core gui widgets printsupport testlib
CONFIG += testcase no_testcase_installs c++17 warn_on
TEMPLATE = app
TARGET = plusplus-editor-tests

# Separate native test executable. It compiles the application classes below
# but deliberately excludes ../main.cpp, so tests never enter the real app.
INCLUDEPATH += ..

SOURCES += \
    tst_editor.cpp \
    ../mainwindow.cpp \
    ../form.cpp \
    ../themes.cpp

HEADERS += \
    ../appinfo.h \
    ../mainwindow.h \
    ../form.h \
    ../themes.h

FORMS += \
    ../mainwindow.ui \
    ../form.ui

RESOURCES += ../resources.qrc

DEFINES += QT_DEPRECATED_WARNINGS

unix:!macx {
    QMAKE_CXXFLAGS += -Wall -Wextra -Wpedantic
}

sanitize {
    QMAKE_CXXFLAGS += -fsanitize=address,undefined -fno-omit-frame-pointer
    QMAKE_LFLAGS += -fsanitize=address,undefined
}

# Preserve readable stack traces when Memcheck runs the Debug test binary.
valgrind {
    QMAKE_CXXFLAGS += -fno-omit-frame-pointer
}
