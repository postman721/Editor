// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#pragma once

#include <QPlainTextEdit>
#include <QRect>
#include <QWidget>

class QEvent;
class QInputMethodEvent;
class QKeyEvent;
class QMimeData;
class QPaintEvent;
class QResizeEvent;
class LineNumberArea;

namespace Ui
{
class Form;
}

// The editor widget keeps the two editor-specific concerns in one place:
// bounded text input and a lightweight line-number gutter.
class EditorTextEdit final : public QPlainTextEdit
{
    Q_OBJECT

public:
    explicit EditorTextEdit(QWidget *parent = nullptr);

signals:
    void inputRejected(const QString &message);

protected:
    void changeEvent(QEvent *event) override;
    void inputMethodEvent(QInputMethodEvent *event) override;
    void insertFromMimeData(const QMimeData *source) override;
    void keyPressEvent(QKeyEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    friend class LineNumberArea;

    bool canInsert(qsizetype incomingCharacters) const;
    void highlightCurrentLine();
    int lineNumberAreaWidth() const;
    void paintLineNumbers(QPaintEvent *event);
    void updateLineNumberArea(const QRect &rect, int dy);
    void updateLineNumberAreaWidth();

    LineNumberArea *lineNumberArea_ = nullptr;
};

// Form deliberately follows the original project's one-tab/one-widget model.
// It owns the editor, file path, file I/O, printing, and unsaved-change prompt.
class Form final : public QWidget
{
    Q_OBJECT

public:
    explicit Form(int untitledNumber, QWidget *parent = nullptr);
    ~Form() override;

    EditorTextEdit *editor() const;
    QString filePath() const;
    QString displayName() const;
    bool isUntitled() const;
    bool isModified() const;
    bool isBlank() const;

    // File operations return false and optionally describe the error.
    bool openFile(const QString &path, QString *error = nullptr);
    bool saveFile(const QString &path, QString *error = nullptr);
    bool save(QWidget *dialogParent);
    bool saveAs(QWidget *dialogParent);
    bool confirmClose(QWidget *dialogParent);
    void printDocument(QWidget *dialogParent);
    void setWordWrap(bool enabled);

signals:
    void titleChanged();
    void cursorChanged(int line, int column);
    void message(const QString &text);

private:
    void setFilePath(const QString &path);

    Ui::Form *ui;
    QString filePath_;
    int untitledNumber_;
};
