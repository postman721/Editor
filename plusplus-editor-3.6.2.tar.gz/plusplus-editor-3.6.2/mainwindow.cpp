// SPDX-FileCopyrightText: 2020-2026 JJ Posti <https://www.techtimejourney.net>
// SPDX-License-Identifier: GPL-2.0-or-later OR Apache-2.0

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "appinfo.h"
#include "form.h"

#include <QAction>
#include <QActionGroup>
#include <QApplication>
#include <QClipboard>
#include <QCloseEvent>
#include <QColor>
#include <QColorDialog>
#include <QComboBox>
#include <QDir>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QFileDialog>
#include <QFileInfo>
#include <QFont>
#include <QFontComboBox>
#include <QFontDatabase>
#include <QGuiApplication>
#include <QIcon>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QMenuBar>
#include <QMessageBox>
#include <QMimeData>
#include <QPalette>
#include <QPainter>
#include <QPixmap>
#include <QRect>
#include <QScreen>
#include <QSettings>
#include <QSignalBlocker>
#include <QSize>
#include <QSizePolicy>
#include <QSpinBox>
#include <QStatusBar>
#include <QStyle>
#include <QTabBar>
#include <QTextCharFormat>
#include <QTextCursor>
#include <QTextDocument>
#include <QToolBar>
#include <QToolButton>
#include <QUrl>

namespace
{
QIcon actionIcon(const QString &name, QStyle::StandardPixmap fallback,
                 const QWidget *widget)
{
    const QIcon icon = QIcon::fromTheme(name);
    return icon.isNull() ? widget->style()->standardIcon(fallback) : icon;
}

QIcon themeSwatch(const QColor &background, const QColor &accent)
{
    QPixmap pixmap(18, 18);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setPen(QColor(255, 255, 255, 90));
    painter.setBrush(background);
    painter.drawRoundedRect(QRectF(1.0, 1.0, 16.0, 16.0), 4.0, 4.0);
    painter.setPen(Qt::NoPen);
    painter.setBrush(accent);
    painter.drawRoundedRect(QRectF(4.0, 11.0, 10.0, 3.0), 1.5, 1.5);
    return QIcon(pixmap);
}

QToolButton *textToolButton(QToolBar *toolbar, QAction *action,
                            const QString &text, const QString &objectName)
{
    auto *button = qobject_cast<QToolButton *>(toolbar->widgetForAction(action));
    if (!button)
        return nullptr;

    button->setObjectName(objectName);
    button->setToolButtonStyle(Qt::ToolButtonTextOnly);
    action->setIconText(text);
    button->setText(text);
    QString accessibleName = action->text();
    accessibleName.remove(QLatin1Char('&'));
    button->setAccessibleName(accessibleName);
    return button;
}

QString normalizedPath(const QString &path)
{
    const QFileInfo info(path);
    const QString canonical = info.canonicalFilePath();
    return QDir::cleanPath(canonical.isEmpty() ? info.absoluteFilePath() : canonical);
}

bool pathsMatch(const QString &left, const QString &right)
{
#ifdef Q_OS_WIN
    return normalizedPath(left).compare(normalizedPath(right), Qt::CaseInsensitive) == 0;
#else
    return normalizedPath(left) == normalizedPath(right);
#endif
}
}

// Window setup

MainWindow::MainWindow(const QString &startupTheme, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setupInterface();
    setupThemeActions();
    setupActionIcons();
    connectActions();
    loadSettings(startupTheme);
    newTab();

    // Some headless Qt platform plugins expose no clipboard MIME object.
    // Treat clipboard notifications as optional during startup and tests.
    if (QClipboard *clipboard = QApplication::clipboard()) {
        connect(clipboard, &QClipboard::dataChanged,
                this, &MainWindow::updateActions);
    }
    updateActions();
}

// Build the fixed window chrome once; document state remains inside Form.
void MainWindow::setupInterface()
{
    setObjectName(QStringLiteral("mainWindow"));
    setWindowIcon(QIcon(QStringLiteral(":/icons/plusplus-editor.svg")));
    ui->tabWidget->tabBar()->setExpanding(false);
    ui->tabWidget->tabBar()->setDrawBase(false);
    ui->tabWidget->tabBar()->setUsesScrollButtons(true);
    ui->tabWidget->tabBar()->setElideMode(Qt::ElideRight);
    ui->tabWidget->tabBar()->setSelectionBehaviorOnRemove(QTabBar::SelectPreviousTab);
    ui->mainToolBar->setMovable(false);
    ui->mainToolBar->setFloatable(false);
    ui->mainToolBar->setAllowedAreas(Qt::TopToolBarArea);
    ui->mainToolBar->setIconSize(QSize(20, 20));
    ui->statusBar->setSizeGripEnabled(false);

    fontComboBox_ = new QFontComboBox(ui->mainToolBar);
    fontComboBox_->setFontFilters(QFontComboBox::ScalableFonts);
    fontComboBox_->setCurrentFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    fontComboBox_->setObjectName(QStringLiteral("fontComboBox"));
    fontComboBox_->setMinimumContentsLength(10);
    fontComboBox_->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    fontComboBox_->setMinimumWidth(120);
    fontComboBox_->setMaximumWidth(176);
    fontComboBox_->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
    fontComboBox_->setToolTip(tr("Editor font"));
    fontComboBox_->setAccessibleName(tr("Editor font"));
    ui->mainToolBar->insertWidget(ui->actionBold, fontComboBox_);

    fontSizeSpinBox_ = new QSpinBox(ui->mainToolBar);
    fontSizeSpinBox_->setRange(6, 72);
    fontSizeSpinBox_->setValue(11);
    fontSizeSpinBox_->setSuffix(tr(" pt"));
    fontSizeSpinBox_->setObjectName(QStringLiteral("fontSizeSpinBox"));
    fontSizeSpinBox_->setMinimumWidth(62);
    fontSizeSpinBox_->setMaximumWidth(74);
    fontSizeSpinBox_->setToolTip(tr("Font size"));
    fontSizeSpinBox_->setAccessibleName(tr("Font size"));
    ui->mainToolBar->insertWidget(ui->actionBold, fontSizeSpinBox_);

    auto *newTabButton = new QToolButton(ui->tabWidget);
    newTabButton->setObjectName(QStringLiteral("newTabButton"));
    newTabButton->setText(QStringLiteral("+"));
    newTabButton->setToolButtonStyle(Qt::ToolButtonTextOnly);
    newTabButton->setAutoRaise(true);
    newTabButton->setToolTip(tr("New document"));
    newTabButton->setAccessibleName(tr("New document"));
    ui->tabWidget->setCornerWidget(newTabButton, Qt::TopRightCorner);
    connect(newTabButton, &QToolButton::clicked, this, &MainWindow::newTab);

    pathLabel_ = new QLabel(this);
    pathLabel_->setObjectName(QStringLiteral("pathLabel"));
    pathLabel_->setTextInteractionFlags(Qt::TextSelectableByMouse);
    pathLabel_->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Preferred);
    pathLabel_->setMinimumWidth(0);
    cursorLabel_ = new QLabel(tr("Ln 1, Col 1"), this);
    cursorLabel_->setObjectName(QStringLiteral("cursorLabel"));
    auto *encodingLabel = new QLabel(tr("UTF-8  ·  LF"), this);
    encodingLabel->setObjectName(QStringLiteral("encodingLabel"));
    encodingLabel->setToolTip(tr("Files are opened and saved as UTF-8 with LF line endings"));
    ui->statusBar->addWidget(pathLabel_, 1);
    ui->statusBar->addPermanentWidget(encodingLabel);
    ui->statusBar->addPermanentWidget(cursorLabel_);
}

// Prepare the three exclusive theme actions and their colour swatches.
void MainWindow::setupThemeActions()
{
    themeActions_ = new QActionGroup(this);
    themeActions_->setExclusive(true);
    ui->actionGraphite->setData(Themes::key(Theme::Graphite));
    ui->actionDark->setData(Themes::key(Theme::Dark));
    ui->actionBlue->setData(Themes::key(Theme::Blue));
    themeActions_->addAction(ui->actionGraphite);
    themeActions_->addAction(ui->actionDark);
    themeActions_->addAction(ui->actionBlue);
    ui->actionGraphite->setIcon(themeSwatch(QColor(QStringLiteral("#30353b")),
                                             QColor(QStringLiteral("#4ba2d5"))));
    ui->actionDark->setIcon(themeSwatch(QColor(QStringLiteral("#111419")),
                                        QColor(QStringLiteral("#2f9fe8"))));
    ui->actionBlue->setIcon(themeSwatch(QColor(QStringLiteral("#0b3157")),
                                        QColor(QStringLiteral("#5dc0ff"))));
}

// Prefer system icons, then make the text-format buttons self-explanatory.
void MainWindow::setupActionIcons()
{
    ui->actionNew->setIcon(actionIcon(QStringLiteral("document-new"),
                                      QStyle::SP_FileIcon, this));
    ui->actionOpen->setIcon(actionIcon(QStringLiteral("document-open"),
                                       QStyle::SP_DialogOpenButton, this));
    ui->actionSave->setIcon(actionIcon(QStringLiteral("document-save"),
                                       QStyle::SP_DialogSaveButton, this));
    ui->actionPrint->setIcon(actionIcon(QStringLiteral("document-print"),
                                        QStyle::SP_DialogApplyButton, this));
    ui->actionSaveAs->setIcon(actionIcon(QStringLiteral("document-save-as"),
                                         QStyle::SP_DialogSaveButton, this));
    ui->actionCloseTab->setIcon(actionIcon(QStringLiteral("window-close"),
                                           QStyle::SP_DialogCloseButton, this));
    ui->actionQuit->setIcon(actionIcon(QStringLiteral("application-exit"),
                                       QStyle::SP_DialogCloseButton, this));
    ui->actionUndo->setIcon(actionIcon(QStringLiteral("edit-undo"),
                                       QStyle::SP_ArrowBack, this));
    ui->actionRedo->setIcon(actionIcon(QStringLiteral("edit-redo"),
                                       QStyle::SP_ArrowForward, this));
    ui->actionCut->setIcon(QIcon::fromTheme(QStringLiteral("edit-cut")));
    ui->actionCopy->setIcon(QIcon::fromTheme(QStringLiteral("edit-copy")));
    ui->actionPaste->setIcon(QIcon::fromTheme(QStringLiteral("edit-paste")));
    ui->actionSelectAll->setIcon(QIcon::fromTheme(QStringLiteral("edit-select-all")));
    ui->actionFind->setIcon(QIcon::fromTheme(QStringLiteral("edit-find")));
    ui->actionWordWrap->setIcon(QIcon::fromTheme(QStringLiteral("format-text-wrap")));
    ui->actionZoomIn->setIcon(QIcon::fromTheme(QStringLiteral("zoom-in")));
    ui->actionZoomOut->setIcon(QIcon::fromTheme(QStringLiteral("zoom-out")));
    ui->actionAbout->setIcon(actionIcon(QStringLiteral("help-about"),
                                        QStyle::SP_MessageBoxInformation, this));

    if (QToolButton *button = textToolButton(ui->mainToolBar, ui->actionBold,
                                             QStringLiteral("B"),
                                             QStringLiteral("boldButton"))) {
        QFont font = button->font();
        font.setBold(true);
        button->setFont(font);
    }
    if (QToolButton *button = textToolButton(ui->mainToolBar, ui->actionItalic,
                                             QStringLiteral("I"),
                                             QStringLiteral("italicButton"))) {
        QFont font = button->font();
        font.setItalic(true);
        button->setFont(font);
    }
    if (QToolButton *button = textToolButton(ui->mainToolBar, ui->actionUnderline,
                                             QStringLiteral("U"),
                                             QStringLiteral("underlineButton"))) {
        QFont font = button->font();
        font.setUnderline(true);
        button->setFont(font);
    }
    textToolButton(ui->mainToolBar, ui->actionTextColor, QStringLiteral("A"),
                   QStringLiteral("textColorButton"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::tabCount() const
{
    return ui->tabWidget->count();
}

Form *MainWindow::currentForm() const
{
    return formAt(ui->tabWidget->currentIndex());
}

EditorTextEdit *MainWindow::currentEditor() const
{
    Form *form = currentForm();
    return form ? form->editor() : nullptr;
}

Theme MainWindow::currentTheme() const
{
    return currentTheme_;
}

// Menus, toolbar, and shared actions

// Shared actions always target the currently selected Form.
void MainWindow::connectActions()
{
    ui->actionQuit->setMenuRole(QAction::QuitRole);
    ui->actionAbout->setMenuRole(QAction::AboutRole);

    connect(ui->actionNew, &QAction::triggered, this, &MainWindow::newTab);
    connect(ui->actionOpen, &QAction::triggered, this, &MainWindow::openDialog);
    connect(ui->actionSave, &QAction::triggered, this, &MainWindow::saveCurrent);
    connect(ui->actionSaveAs, &QAction::triggered, this, &MainWindow::saveCurrentAs);
    connect(ui->actionPrint, &QAction::triggered, this, &MainWindow::printCurrent);
    connect(ui->actionCloseTab, &QAction::triggered, this, [this] {
        closeTab(ui->tabWidget->currentIndex());
    });
    connect(ui->actionQuit, &QAction::triggered, this, &QWidget::close);

    connect(ui->actionUndo, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->undo();
    });
    connect(ui->actionRedo, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->redo();
    });
    connect(ui->actionCut, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->cut();
    });
    connect(ui->actionCopy, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->copy();
    });
    connect(ui->actionPaste, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->paste();
    });
    connect(ui->actionSelectAll, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->selectAll();
    });
    connect(ui->actionFind, &QAction::triggered, this, &MainWindow::findText);

    connect(ui->actionBold, &QAction::toggled, this, &MainWindow::setBold);
    connect(ui->actionItalic, &QAction::toggled, this, &MainWindow::setItalic);
    connect(ui->actionUnderline, &QAction::toggled, this, &MainWindow::setUnderline);
    connect(ui->actionTextColor, &QAction::triggered,
            this, &MainWindow::chooseTextColor);
    connect(ui->actionWordWrap, &QAction::toggled,
            this, &MainWindow::setWordWrap);
    connect(ui->actionZoomIn, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->zoomIn(1);
    });
    connect(ui->actionZoomOut, &QAction::triggered, this, [this] {
        if (EditorTextEdit *editor = currentEditor())
            editor->zoomOut(1);
    });
    connect(fontComboBox_, &QFontComboBox::currentFontChanged,
            this, &MainWindow::setEditorFont);
    connect(fontSizeSpinBox_, &QSpinBox::valueChanged,
            this, &MainWindow::setEditorFontSize);

    connect(ui->actionGraphite, &QAction::triggered,
            this, [this] { setTheme(Theme::Graphite); });
    connect(ui->actionDark, &QAction::triggered,
            this, [this] { setTheme(Theme::Dark); });
    connect(ui->actionBlue, &QAction::triggered,
            this, [this] { setTheme(Theme::Blue); });
    connect(ui->actionAbout, &QAction::triggered, this, &MainWindow::showAbout);

    connect(ui->tabWidget, &QTabWidget::tabCloseRequested,
            this, &MainWindow::closeTab);
    connect(ui->tabWidget, &QTabWidget::currentChanged,
            this, &MainWindow::updateActions);
    connect(ui->tabWidget->tabBar(), &QTabBar::tabBarDoubleClicked,
            this, [this](int) { newTab(); });
}

// Tabs and files

// Create one self-owned document tab and connect only its local signals.
Form *MainWindow::addForm()
{
    if (ui->tabWidget->count() >= AppInfo::MaxTabs) {
        QMessageBox::information(this, tr("Document limit"),
                                 tr("++Editor keeps at most 12 documents open."));
        return nullptr;
    }

    auto *form = new Form(nextUntitledNumber_++, ui->tabWidget);
    QFont font = fontComboBox_->currentFont();
    font.setPointSize(fontSizeSpinBox_->value());

    // Applying UI defaults is not a document edit. QTextDocument may mark
    // itself modified when its default font changes, so restore the clean
    // state before the tab becomes visible or is considered for reuse.
    QTextDocument *document = form->editor()->document();
    form->editor()->setFont(font);
    document->setDefaultFont(font);
    document->setModified(false);
    form->setWordWrap(wordWrap_);

    connect(form, &Form::titleChanged,
            this, [this, form] { updateTabTitle(form); });
    connect(form, &Form::cursorChanged,
            this, [this, form](int line, int column) {
                if (form == currentForm())
                    cursorLabel_->setText(tr("Ln %1, Col %2").arg(line).arg(column));
            });
    connect(form, &Form::message,
            this, [this](const QString &text) {
                ui->statusBar->showMessage(text, 3500);
            });
    connect(form->editor()->document(), &QTextDocument::undoAvailable,
            this, &MainWindow::updateActions);
    connect(form->editor()->document(), &QTextDocument::redoAvailable,
            this, &MainWindow::updateActions);
    connect(form->editor(), &QPlainTextEdit::copyAvailable,
            this, &MainWindow::updateActions);
    connect(form->editor(), &QPlainTextEdit::cursorPositionChanged,
            this, [this, form] {
                if (form == currentForm())
                    updateFormatControls();
            });

    const int index = ui->tabWidget->addTab(form, form->displayName());
    ui->tabWidget->setCurrentIndex(index);
    updateTabTitle(form);
    return form;
}

Form *MainWindow::formAt(int index) const
{
    return qobject_cast<Form *>(ui->tabWidget->widget(index));
}

void MainWindow::newTab()
{
    addForm();
}

void MainWindow::closeTab(int index)
{
    Form *form = formAt(index);
    if (!form || !form->confirmClose(this))
        return;

    ui->tabWidget->removeTab(index);
    form->deleteLater();
    if (ui->tabWidget->count() == 0)
        addForm();
    updateActions();
}

// Reuse the initial blank tab; otherwise open the file in a new tab.
bool MainWindow::openFile(const QString &path)
{
    if (path.trimmed().isEmpty())
        return false;

    const int existing = indexOfOpenFile(path);
    if (existing >= 0) {
        ui->tabWidget->setCurrentIndex(existing);
        return true;
    }

    Form *target = currentForm();
    const bool reuseCurrent = target && target->isBlank();
    if (!reuseCurrent)
        target = addForm();
    if (!target)
        return false;

    QString error;
    if (!target->openFile(path, &error)) {
        if (!reuseCurrent) {
            const int index = ui->tabWidget->indexOf(target);
            if (index >= 0)
                ui->tabWidget->removeTab(index);
            target->deleteLater();
        }
        QMessageBox::warning(this, tr("Open failed"), error);
        return false;
    }

    updateTabTitle(target);
    updateActions();
    return true;
}

int MainWindow::openFiles(const QStringList &paths)
{
    int opened = 0;
    int attempted = 0;
    for (const QString &path : paths) {
        if (attempted >= AppInfo::MaxTabs)
            break;
        if (openFile(path))
            ++opened;
        ++attempted;
    }
    return opened;
}

int MainWindow::indexOfOpenFile(const QString &path) const
{
    for (int index = 0; index < ui->tabWidget->count(); ++index) {
        const Form *form = formAt(index);
        if (form && !form->filePath().isEmpty() && pathsMatch(form->filePath(), path))
            return index;
    }
    return -1;
}

void MainWindow::openDialog()
{
    const QStringList paths = QFileDialog::getOpenFileNames(
        this, tr("Open text files"), QDir::homePath(),
        tr("Text files (*.txt *.md *.log *.json *.xml *.cpp *.h);;All files (*)"));
    openFiles(paths);
}

void MainWindow::saveCurrent()
{
    Form *form = currentForm();
    if (form && form->save(this))
        updateTabTitle(form);
}

void MainWindow::saveCurrentAs()
{
    Form *form = currentForm();
    if (form && form->saveAs(this))
        updateTabTitle(form);
}

void MainWindow::printCurrent()
{
    if (Form *form = currentForm())
        form->printDocument(this);
}

void MainWindow::findText()
{
    EditorTextEdit *editor = currentEditor();
    if (!editor)
        return;

    bool accepted = false;
    const QString query = QInputDialog::getText(
        this, tr("Find"), tr("Find text:"), QLineEdit::Normal,
        lastSearch_, &accepted).left(4096);
    if (!accepted || query.isEmpty())
        return;
    lastSearch_ = query;

    if (!editor->find(query)) {
        QTextCursor cursor(editor->document());
        cursor.movePosition(QTextCursor::Start);
        editor->setTextCursor(cursor);
        if (!editor->find(query)) {
            ui->statusBar->showMessage(tr("Text not found"), 2500);
            return;
        }
    }
    ui->statusBar->showMessage(tr("Match found"), 1200);
}

// Editing and formatting

void MainWindow::setBold(bool enabled)
{
    QTextCharFormat format;
    format.setFontWeight(enabled ? QFont::Bold : QFont::Normal);
    mergeFormat(format);
}

void MainWindow::setItalic(bool enabled)
{
    QTextCharFormat format;
    format.setFontItalic(enabled);
    mergeFormat(format);
}

void MainWindow::setUnderline(bool enabled)
{
    QTextCharFormat format;
    format.setFontUnderline(enabled);
    mergeFormat(format);
}

void MainWindow::chooseTextColor()
{
    EditorTextEdit *editor = currentEditor();
    if (!editor)
        return;

    QColor initialColor = editor->currentCharFormat().foreground().color();
    if (!initialColor.isValid())
        initialColor = editor->palette().color(QPalette::Text);
    const QColor color = QColorDialog::getColor(
        initialColor, this, tr("Choose text colour"));
    if (!color.isValid())
        return;

    QTextCharFormat format;
    format.setForeground(color);
    mergeFormat(format);
}

void MainWindow::setEditorFont(const QFont &font)
{
    QTextCharFormat format;
    format.setFontFamilies(QStringList{font.family()});
    mergeFormat(format);
}

void MainWindow::setEditorFontSize(int pointSize)
{
    QTextCharFormat format;
    format.setFontPointSize(pointSize);
    mergeFormat(format);
}

void MainWindow::mergeFormat(const QTextCharFormat &format)
{
    EditorTextEdit *editor = currentEditor();
    if (!editor)
        return;

    editor->mergeCurrentCharFormat(format);
    updateFormatControls();
}

void MainWindow::setWordWrap(bool enabled)
{
    wordWrap_ = enabled;
    for (int index = 0; index < ui->tabWidget->count(); ++index) {
        if (Form *form = formAt(index))
            form->setWordWrap(enabled);
    }
}

// Visible state

void MainWindow::updateTabTitle(Form *form)
{
    if (!form)
        return;
    const int index = ui->tabWidget->indexOf(form);
    if (index < 0)
        return;

    QString title = form->displayName();
    if (form->isModified())
        title += QLatin1Char('*');
    ui->tabWidget->setTabText(index, title);
    ui->tabWidget->setTabToolTip(index, form->filePath().isEmpty()
                                            ? title
                                            : QDir::toNativeSeparators(form->filePath()));
    if (form == currentForm())
        updateActions();
}

void MainWindow::updateActions()
{
    Form *form = currentForm();
    EditorTextEdit *editor = form ? form->editor() : nullptr;
    const bool hasForm = editor != nullptr;
    const bool hasSelection = editor && editor->textCursor().hasSelection();

    ui->actionSave->setEnabled(hasForm);
    ui->actionSaveAs->setEnabled(hasForm);
    ui->actionPrint->setEnabled(hasForm);
    ui->actionCloseTab->setEnabled(hasForm);
    ui->actionUndo->setEnabled(editor && editor->document()->isUndoAvailable());
    ui->actionRedo->setEnabled(editor && editor->document()->isRedoAvailable());
    ui->actionCut->setEnabled(hasSelection);
    ui->actionCopy->setEnabled(hasSelection);
    bool canPaste = false;
    if (editor) {
        if (const QClipboard *clipboard = QApplication::clipboard()) {
            if (const QMimeData *mimeData = clipboard->mimeData())
                canPaste = mimeData->hasText();
        }
    }
    ui->actionPaste->setEnabled(canPaste);
    ui->actionSelectAll->setEnabled(editor && editor->document()->characterCount() > 1);
    ui->actionFind->setEnabled(hasForm);
    ui->actionBold->setEnabled(hasForm);
    ui->actionItalic->setEnabled(hasForm);
    ui->actionUnderline->setEnabled(hasForm);
    ui->actionTextColor->setEnabled(hasForm);
    ui->actionZoomIn->setEnabled(hasForm);
    ui->actionZoomOut->setEnabled(hasForm);
    fontComboBox_->setEnabled(hasForm);
    fontSizeSpinBox_->setEnabled(hasForm);

    if (!form) {
        pathLabel_->clear();
        pathLabel_->setToolTip(QString());
        cursorLabel_->setText(tr("Ln 1, Col 1"));
        setWindowTitle(QString::fromLatin1(AppInfo::DisplayName));
        return;
    }

    const QString pathText = form->filePath().isEmpty()
                                 ? form->displayName()
                                 : QDir::toNativeSeparators(form->filePath());
    pathLabel_->setText(pathText);
    pathLabel_->setToolTip(pathText);
    const QTextCursor cursor = editor->textCursor();
    cursorLabel_->setText(tr("Ln %1, Col %2")
                              .arg(cursor.blockNumber() + 1)
                              .arg(cursor.positionInBlock() + 1));

    QString title = form->displayName();
    if (form->isModified())
        title += QLatin1Char('*');
    setWindowTitle(tr("%1 — %2").arg(title, QString::fromLatin1(AppInfo::DisplayName)));
    updateFormatControls();
}

void MainWindow::updateFormatControls()
{
    EditorTextEdit *editor = currentEditor();
    if (!editor)
        return;

    const QTextCharFormat format = editor->currentCharFormat();
    const QSignalBlocker boldBlocker(ui->actionBold);
    const QSignalBlocker italicBlocker(ui->actionItalic);
    const QSignalBlocker underlineBlocker(ui->actionUnderline);
    const QSignalBlocker fontBlocker(fontComboBox_);
    const QSignalBlocker sizeBlocker(fontSizeSpinBox_);

    ui->actionBold->setChecked(format.fontWeight() >= QFont::Bold);
    ui->actionItalic->setChecked(format.fontItalic());
    ui->actionUnderline->setChecked(format.fontUnderline());

    QFont font = format.font();
    if (font.family().isEmpty())
        font = editor->font();
    fontComboBox_->setCurrentFont(font);
    if (font.pointSize() > 0)
        fontSizeSpinBox_->setValue(font.pointSize());
}

// Settings and themes

// Apply one palette/QSS pair and optionally persist the selected key.
void MainWindow::setTheme(Theme theme, bool saveChoice)
{
    QString error;
    if (!Themes::apply(*qApp, theme, &error)) {
        QMessageBox::warning(this, tr("Theme error"), error);
        return;
    }

    currentTheme_ = theme;
    const QString selectedKey = Themes::key(theme);
    for (QAction *action : themeActions_->actions()) {
        const QSignalBlocker blocker(action);
        action->setChecked(action->data().toString() == selectedKey);
    }

    if (saveChoice) {
        QSettings settings(QString::fromLatin1(AppInfo::OrganizationName),
                           QString::fromLatin1(AppInfo::SettingsName));
        settings.setValue(QStringLiteral("theme"), selectedKey);
        settings.sync(); // Write now so the choice survives logout or reboot.
        if (settings.status() != QSettings::NoError) {
            ui->statusBar->showMessage(
                tr("Theme changed, but the preference could not be saved."), 5000);
        }
    }
}

// Load the saved values first. A valid --theme value is then applied and saved.
void MainWindow::loadSettings(const QString &startupTheme)
{
    QSettings settings(QString::fromLatin1(AppInfo::OrganizationName),
                       QString::fromLatin1(AppInfo::SettingsName));
    const QByteArray geometry = settings.value(QStringLiteral("geometry")).toByteArray();
    const bool restored = !geometry.isEmpty() && geometry.size() <= 64 * 1024
                          && restoreGeometry(geometry);

    wordWrap_ = settings.value(QStringLiteral("wordWrap"), true).toBool();
    ui->actionWordWrap->setChecked(wordWrap_);

    QString family = settings.value(
        QStringLiteral("fontFamily"), fontComboBox_->currentFont().family()).toString();
    if (family.size() > 128)
        family.clear();
    if (!family.isEmpty())
        fontComboBox_->setCurrentFont(QFont(family));
    fontSizeSpinBox_->setValue(qBound(
        6, settings.value(QStringLiteral("fontSize"), 11).toInt(), 72));

    Theme theme = Theme::Graphite;
    Themes::fromKey(settings.value(QStringLiteral("theme"),
                                   Themes::key(Theme::Graphite)).toString(), &theme);
    if (!startupTheme.isEmpty())
        Themes::fromKey(startupTheme, &theme);
    setTheme(theme, !startupTheme.isEmpty());
    fitWindowToScreen(!restored);
}

// Constrain both default and restored geometry to the active screen.
void MainWindow::fitWindowToScreen(bool useDefaultSize)
{
    QScreen *screen = QGuiApplication::screenAt(frameGeometry().center());
    if (!screen)
        screen = QGuiApplication::primaryScreen();
    if (!screen)
        return;

    QRect available = screen->availableGeometry().adjusted(12, 12, -12, -12);
    if (available.width() < 320 || available.height() < 240)
        available = screen->availableGeometry();

    QSize windowSize = useDefaultSize ? QSize(1000, 680) : size();
    // Keep all startup chrome visible whenever the screen is wide enough.
    const int chromeWidth = qMax(ui->mainToolBar->sizeHint().width(),
                                 menuBar()->sizeHint().width()) + 24;
    const QSize usefulMinimum(qMax(640, chromeWidth), 420);
    windowSize = windowSize.expandedTo(usefulMinimum.boundedTo(available.size()));
    windowSize = windowSize.boundedTo(available.size());

    QRect target(pos(), windowSize);
    if (!available.contains(target))
        target.moveCenter(available.center());
    target.moveLeft(qBound(available.left(), target.left(),
                           available.right() - target.width() + 1));
    target.moveTop(qBound(available.top(), target.top(),
                          available.bottom() - target.height() + 1));
    setGeometry(target);
}

void MainWindow::saveSettings()
{
    QSettings settings(QString::fromLatin1(AppInfo::OrganizationName),
                       QString::fromLatin1(AppInfo::SettingsName));
    settings.setValue(QStringLiteral("geometry"), saveGeometry());
    settings.setValue(QStringLiteral("theme"), Themes::key(currentTheme_));
    settings.setValue(QStringLiteral("wordWrap"), wordWrap_);
    settings.setValue(QStringLiteral("fontFamily"), fontComboBox_->currentFont().family());
    settings.setValue(QStringLiteral("fontSize"), fontSizeSpinBox_->value());
    settings.sync();
}

void MainWindow::showAbout()
{
    QMessageBox::about(
        this, tr("About ++Editor"),
        tr("<h3>++Editor %1</h3>"
           "<p>A polished traditional Qt 6 text editor with line numbers, tabs, "
           "current-line highlighting, and the LWM Graphite, Dark, and Blue themes.</p>"
           "<p>The source follows the original design: MainWindow manages tabs, "
           "Form owns one document, and Themes loads the three style sheets.</p>"
           "<p>Copyright © 2020–2026 JJ Posti, techtimejourney.net.</p>")
            .arg(QString::fromLatin1(AppInfo::Version)));
}

// Window events

void MainWindow::closeEvent(QCloseEvent *event)
{
    for (int index = 0; index < ui->tabWidget->count(); ++index) {
        Form *form = formAt(index);
        if (form && !form->confirmClose(this)) {
            event->ignore();
            return;
        }
    }
    saveSettings();
    event->accept();
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event)
{
    if (!event || !event->mimeData()->hasUrls())
        return;
    for (const QUrl &url : event->mimeData()->urls()) {
        if (url.isLocalFile()) {
            event->acceptProposedAction();
            return;
        }
    }
}

void MainWindow::dropEvent(QDropEvent *event)
{
    if (!event || !event->mimeData()->hasUrls())
        return;

    int attempted = 0;
    for (const QUrl &url : event->mimeData()->urls()) {
        if (attempted >= AppInfo::MaxTabs)
            break;
        if (url.isLocalFile()) {
            openFile(url.toLocalFile());
            ++attempted;
        }
    }
    event->acceptProposedAction();
}
